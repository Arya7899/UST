from flask import Flask, render_template, request, redirect
from pymongo import MongoClient


app = Flask(__name__)

# mongodb connection
client = MongoClient("mongodb://admin:password@localhost:27017")
print(client)
db = client['training']
collections = db['courses']
userip_collections = db['usersIP']


@app.route('/TrainingCourses')
def Training():
    return "<p>Welcome to ust training courses</p>"


@app.route('/')
def hello_world():
    return render_template('index.html')

# add courses
@app.route('/add', methods=['GET', 'POST'])
def add_courses():
    if request.method == "POST":
        courseid = request.form['courseid']
        coursename = request.form['coursename']
        desc = request.form['desc']

        course_dict = {'courseid': courseid,
                       'coursename': coursename, 'desc': desc}
        collections.insert_one(course_dict)
        return redirect('/')

    return render_template("add.html")

# VIEW ALL COURSES
@app.route('/viewcourses', methods=['GET'])
def view_courses():
    ust_courses = collections.find()
    # request login users ip address
    login_users = request.remote_addr 
    # store users ip address in a collection userIP            
    userip_collections.insert_one({'userIP':login_users })     
    return render_template("view.html", allCourses=ust_courses)


# VIEW COURSE BY COURSENAME
@app.route("/viewcourses", methods=['POST', 'GET'])
def search_course():
    course_name = request.form['coursename']
    courses = collections.find({'coursename': course_name})
    return render_template('view.html', allCourses=courses)

# VIEW EACH COURSE DESCRIPTION
@app.route("/dashboard/<string:courseid>", methods=['GET'])
def view_desc(courseid):
    courses_desc = collections.find({'courseid': courseid})
    return render_template('dashboard.html', allCourses=courses_desc)

# UPDATE COURSES
@app.route("/update/<string:courseid>", methods=['GET', 'POST'])
def update_courses(courseid):
    if request.method == 'POST':
        courseid = request.form['courseid']
        coursename = request.form['coursename']
        desc = request.form['desc']
        collections.update_one(
            {'courseid': courseid}, {'$set': {'coursename': coursename, 'desc': desc}})
        return redirect('/viewcourses')

    updated_courses = collections.find_one({'courseid': courseid})
    return render_template('update.html', allCourses=updated_courses)

# DELETE COURSE

@app.route("/delete/<string:courseid>", methods=['GET'])
def delete_courses(courseid):
    collections.delete_one({'courseid': courseid})
    return redirect('/viewcourses')


if __name__ == "__main__":
    app.run(host = '0.0.0.0', debug=True, port=8080)
